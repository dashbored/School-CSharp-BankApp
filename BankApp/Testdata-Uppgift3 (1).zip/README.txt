Beskrivning av bankdata.txt

Första raden innehåller antalet kunder på följande rader.
91

Kunder
1015;552060-3431;Comércio Mineiro;Av. dos Lusíadas, 23;São Paulo;SP;05432-043;Brazil;(11) 555-7647

Varje kund står på en rad. Semikolon separerar värdena åt.
1015                   - Kundnummer
552060-3431            - Organisationsnummer
Comércio Mineiro       - Företagsnamn
Av. dos Lusíadas, 23   - Adress
São Paulo              - Stad
SP                     - Region
05432-043              - Postnummer
Brazil                 - Land
(11) 555-7647          - Telefonnummer

Efter kunderna kommer en siffra som innehåller antalet bankkonton.
382

Varje bankkonto står på en rad. Semikolon separerar värdena åt.
13001;1001;814.50

13001                  - Kontonummer
1001                   - Kundnummer på ägaren av kontot
814.50                 - Saldo på bankkontot